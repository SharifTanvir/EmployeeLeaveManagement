<?php
include "db.php";

$flag;
if ($_SESSION['employee']){
    $id = $_SESSION['employee'];
    $flag=0;
}
else if ($_SESSION['admin']){
    $id = $_SESSION['admin'];
    $flag=1;
}
else{
    $id = $_SESSION['hr'];
    $flag=2;
}

    $serial=$_GET["id"];
    $status=$_GET["status"];
    $sqlupload= "UPDATE infoofleave SET l_status='$status' where infoofleave.l_id = $serial ";
    $runupload = $conn->prepare($sqlupload);
    $runupload->execute();


if ($flag==0){
    header("Location: employeepanel.php");
}
else if ($flag==1){
    header("Location: adminpanel.php");
}
else{
    header("Location: hrpanel.php");
}



?>