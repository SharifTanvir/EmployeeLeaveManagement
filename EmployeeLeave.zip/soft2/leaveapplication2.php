<?php
include "db.php";
session_start();

$flag;
if ($_SESSION['employee']){
    $id = $_SESSION['employee'];
    $flag=0;
}
else if ($_SESSION['admin']){
    $id = $_SESSION['admin'];
    $flag=1;
}
else{
    $id = $_SESSION['hr'];
    $flag=2;
}
?>
<?php
if(isset($_POST["add"])){
    $errorss= 0;

    $emid=$id;
    $from = $_POST["from"];
    $to = $_POST["to"];
    $type = $_POST["add_typ"];
    $des = $_POST["description"];
    $status = "pending";
    $supervisor=0;
    $dept="";
    $project="";

    $sql = "SELECT em_department FROM employee WHERE em_id = '$emid'" ;
    $check_query = $conn->prepare($sql);
    $check_query->execute();
    if($check_query->rowCount() > 0){

        while ($row = $check_query->fetch(PDO::FETCH_ASSOC)) {
            $dept = $row["em_department"];
        }
    }
    else{
        echo '<script>alert("Something wrong");</script>';
        $errorss=1;
    }

        $sql = "SELECT hr_id FROM hradmin WHERE hr_department= '$dept' ORDER BY RAND() LIMIT 1 " ;
        $check_query = $conn->prepare($sql);
        $check_query->execute();
        if($check_query->rowCount() > 0){
            while ($row = $check_query->fetch(PDO::FETCH_ASSOC)) {
                $supervisor = $row["hr_id"];
            }

        }else{
            echo '<script>alert("Something wrong");</script>';
            $errorss=1;
        }


    if( $errorss !=1 && isset($_POST["add"])){

        $sqlupload = "insert into infoofleave(employee_id,l_from,l_to,l_des,l_status,l_type,leave_monitorer)values ('$emid','$from','$to','$des','$status','$type','$supervisor')";
        echo $sqlupload;
        $runupload = $conn->prepare($sqlupload);
        $runupload->execute();
        if ($flag==0){
            header("Location: employeepanel.php");
        }
        else if ($flag==1){
            header("Location: adminpanel.php");
        }
        else{
            header("Location: hrpanel.php");
        }


    }
    else{
        echo '<script>alert("something wrong!");</script>';
    }

}

?>

<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
<!-- Document Meta
    ============================================= -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--IE Compatibility Meta-->
<meta name="author" content="zytheme" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="description" content="construction html5 template">
<link href="assets/images/favicon/favicon.ico" rel="icon">

<!-- Fonts
    ============================================= -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i%7CRaleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i%7CUbuntu:300,300i,400,400i,500,500i,700,700i' rel='stylesheet' type='text/css'>

<!-- Stylesheets
    ============================================= -->
<link href="assets/css/external.css" rel="stylesheet">
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/custom.css" rel="stylesheet">

<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
<!--[if lt IE 9]>
      <script src="assets/js/html5shiv.js"></script>
      <script src="assets/js/respond.min.js"></script>
    <![endif]-->

<!-- Document Title
    ============================================= -->
<title>Leave Mamagement</title>
</head>
<body>
<!-- Document Wrapper
	============================================= -->
<div id="wrapper" class="wrapper clearfix">
    <header id="navbar-spy" class="header header-1">

        <!-- .top-bar end -->
        <nav id="primary-menu" class="navbar navbar-fixed-top">
            <?php include 'inc/nav.php'; ?>
        </nav>
    </header>
	
	<!-- Page Title
============================================= -->
	<section id="page-title" class="page-title">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-6">
					<h1>Apply For Leave</h1>
				</div>
				<!-- .col-md-6 end -->
				<div class="col-xs-12 col-sm-12 col-md-6">
					<ol class="breadcrumb text-right">
						<li>
							<a href="index.html"></a>
						</li>
						<li class="active"></li>
					</ol>
				</div>
				<!-- .col-md-6 end -->
			</div>
			<!-- .row end -->
		</div>
		<!-- .container end -->
	</section>
	<!-- #page-title end -->
	
	<div class="clearfix mb-150"></div>
	
	<!-- Register Section
============================================= -->
	<section id="register" class="register">
		<div class="container">
            <form class="m-t" role="form" method="post" action="">
                <label class="col-sm-12 control-label">From</label>
                <div class="form-group">
                    <input class="form-control" placeholder="from" id="from" name="from" required="" type="date">
                </div>
                <label class="col-sm-12 control-label">To</label>
                <div class="form-group">
                    <input class="form-control" placeholder="to" id="to" name="to" required="" type="date">
                </div>

                <label class="col-sm-12 control-label">Type Name</label>
                <div class="col-sm-10">
                    <select class="form-control m-b" id="add_typ" name="add_typ" required>
                        <option>select a type</option>

                        <?php
                        $sql = "SELECT * FROM typeofleave" ;
                        $check_query = $conn->prepare($sql);
                        $check_query->execute();
                        if($check_query->rowCount() > 0) {
                            while ($row = $check_query->fetch(PDO::FETCH_ASSOC)) {
                                $cattt = $row["type_name"];
                                $dept_id = $row["type_id"];
                                echo' <option value="'.$dept_id.'">'.$cattt.'</option>';
                            }
                        }?>

                    </select>
                </div>

                <label class="col-sm-12 control-label">Description</label>
                <div class="form-group">
                    <input class="form-control" placeholder="write the reason" id="description" name="description" required="" type="text">
                </div>

                <button type="submit" class="btn btn-primary block full-width m-b" id="add" name="add">APPLY</button>
            </form>
			<!-- .row end -->
		</div>
		<!-- .container end -->
	</section>
	<!-- #register end -->
	
	<div class="clearfix mb-150"></div>
	
	<!-- Footer #1
============================================= -->
	<footer id="footer" class="footer footer-1">
		<!-- Footer Info
	============================================= -->
        <?php include 'inc/footer.php'; ?>
		<!-- .footer-copyright end -->
	</footer>
</div>
<!-- #wrapper end -->

<!-- Footer Scripts
============================================= -->
<script src="assets/js/jquery-2.2.4.min.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/functions.js"></script>
</body>
</html>