<?php
session_start();
if(isset($_SESSION['employee'])){
    unset($_SESSION['employee']);

    header("Location: login.php");
}

if(isset($_SESSION['hr'])){
    unset($_SESSION['hr']);

    header("Location: login.php");
}

if(isset($_SESSION['admin'])){
    unset($_SESSION['admin']);

    header("Location: login.php");
}


?>