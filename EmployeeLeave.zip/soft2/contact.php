
<?php
include "db.php";
session_start();
?>


<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
<!-- Document Meta
    ============================================= -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--IE Compatibility Meta-->
<meta name="author" content="zytheme" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="description" content="construction html5 template">
<link href="assets/images/favicon/favicon.ico" rel="icon">

<!-- Fonts
    ============================================= -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i%7CRaleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i%7CUbuntu:300,300i,400,400i,500,500i,700,700i' rel='stylesheet' type='text/css'>

<!-- Stylesheets
    ============================================= -->
<link href="assets/css/external.css" rel="stylesheet">
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/custom.css" rel="stylesheet">

<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
<!--[if lt IE 9]>
      <script src="assets/js/html5shiv.js"></script>
      <script src="assets/js/respond.min.js"></script>
    <![endif]-->

<!-- Document Title
    ============================================= -->
<title>Leave Management</title>
</head>
<body>
<!-- Document Wrapper
	============================================= -->
<div id="wrapper" class="wrapper clearfix">
	<header id="navbar-spy" class="header header-1">

        <!-- .top-bar end -->
        <nav id="primary-menu" class="navbar navbar-fixed-top">
            <?php include 'inc/nav.php'; ?>
        </nav>
    </header>
	
	<!-- Page Title
============================================= -->
	<section id="page-title" class="page-title">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-6">
					<h1>contact</h1>
				</div>
				<!-- .col-md-6 end -->
				<div class="col-xs-12 col-sm-12 col-md-6">
					<ol class="breadcrumb text-right">
						<li>
							<a href="index.html">Home</a>
						</li>
						<li class="active">contact</li>
					</ol>
				</div>
				<!-- .col-md-6 end -->
			</div>
			<!-- .row end -->
		</div>
		<!-- .container end -->
	</section>
	<!-- #page-title end -->
	
	<!-- Google Maps
============================================= -->
	<section class="google-maps pb-0 pt-0">
		<div class="container-fluid">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 pr-0 pl-0">

                    <div>

                        <iframe
                                width="1800"
                                height="600"
                                frameborder="0" style="border:0"
                                src="https://www.google.com/maps/embed/v1/directions?key= AIzaSyA_8P7zTFIqVjFDSMRlgWlwMSIpc6yElGk &origin='United City, Madani Avenue, Badda, Dhaka 1212' &destination='United City, Madani Avenue, Badda, Dhaka 1212',Bangladesh" allowfullscreen>
                        </iframe>

                    </div>
				</div>
			</div>
		</div>
	</section>
	<!-- .google-maps end -->
	
	<!-- Contact #1
============================================= -->
	<section class="contact">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-8 widget-contact pl-0 pr-0 p-none-xs p-none-sm">
					<form id="contact-form" action="assets/php/sendmail.php" method="post">
						<div class="col-md-6">
							<input type="text" class="form-control mb-30" name="contact-name" id="name" placeholder="Name :" required/>
						</div>
						<div class="col-md-6">
							<input type="email" class="form-control mb-30" name="contact-email" id="email" placeholder="Email :" required/>
						</div>
						<div class="col-md-12">
							<textarea class="form-control mb-30" name="contact-message" id="message" rows="4" placeholder="Message" required></textarea>
						</div>
						<div class="col-md-12">
							<button type="submit" id="submit-message" class="btn btn-primary btn-block">Send Message</button>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-12 mt-xs">
							<!--Alert Message-->
							<div id="contact-result">
							</div>
						</div>
					</form>
				</div>
				<!-- .col-md-8 end -->
				<div class="col-xs-12 col-sm-12 col-md-4">
					<div class="contct-widget-content">
						<p class="mb-0">Lorem ipsum dolor sit amet, adipiscing condimentum tristique vel, eleifend sed turpis. Amet, consectetur adipising elit Integer.</p>
						<div class="widget-contact-info mt-md">
							<div class="col-xs-12 col-sm-12 col-md-6 pl-0 mb-30-xs mb-30-sm">
								<h6>Phone :</h6>
								<p><i class="fa fa-phone"></i>01980860444</p>
								<p class="mb-0"><i class="fa fa-fax"></i>01521207505</p>
							</div>
							<!-- .col-md-6 end -->
							<div class="col-xs-12 col-sm-12 col-md-6">
								<h6>Email :</h6>
								<p class="mb-0"><i class="fa fa-envelope"></i>sharifulislam01674@gmail.com</p>
							</div>
							<!-- .col-md-6 end -->
							<div class="col-xs-12 col-sm-12 col-md-12 pl-0 mt-30 mb-30-xs mb-30-sm">
								<h6>Address :</h6>
								<p class="mb-0"><i class="fa fa-map-marker"></i>United City, Madani Avenue, Badda, Dhaka 1212</p>
							</div>
							<!-- .col-md-12 end -->
						</div>
					</div>
				</div>
				<!-- .col-md-4 end -->
			</div>
			<!-- .row end -->
		</div>
		<!-- .container end -->
	</section>
	
	<!-- Footer #1
============================================= -->
	<footer id="footer" class="footer footer-1">
		<!-- Footer Info
	============================================= -->
             <?php include 'inc/footer.php'; ?>
</div>
<!-- #wrapper end -->

<!-- Footer Scripts
============================================= -->
<script src="assets/js/jquery-2.2.4.min.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/functions.js"></script>
<script type="text/javascript" src="assets/js/plugins/jquery.gmap.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script type="text/javascript">
	$('#googleMap').gMap({
		address: "United City, Madani Avenue, Badda, Dhaka 1212",
		zoom: 15,
		markers:[
			{
				address: "United City, Madani Avenue, Badda, Dhaka 1212",
				maptype:'ROADMAP',
			}
		]
	});
</script>
</body>
</html>