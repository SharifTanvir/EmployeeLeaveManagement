<div class="footer-info">
    <div class="container">

    </div>
    <!-- .container end -->
</div>
<!-- .footer-info end -->



<!-- Footer Bar
============================================= -->
<div class="footer-bar">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-6">
                <div class="powered">
                    <p>Car Shop &copy; All Rights Reserved. With Made With Love By
                        <a href="http://themeforest.net/user/7oroof/portfolio?ref=7oroof">7oroof.com</a>
                    </p>
                    <ul class="list-inline mb-0">
                        <li>
                            <a href="#">Privacy Policy</a>
                        </li>
                        <li>
                            <a href="#">Terms of Use</a>
                        </li>
                        <li>
                            <a href="#">Stores</a>
                        </li>
                        <li>
                            <a href="#">About Us</a>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
    </div>
    <!-- .container end -->
</div>