<?php
include "db.php";
?>

<div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#header-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="logo" href="index.php">
            <img src="assets/images/logo/logo.jpg" alt="Autoshop">
        </a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse pull-right" id="header-navbar-collapse-1">
        <ul class="nav navbar-nav navbar-left">

            <!-- li end -->

            <!-- li end -->
            <?php
                if(isset($_SESSION['employee'])) {

                   echo '<li>
                         <a href="employeepanel.php">Dashboard</a>
                    </li>';

                    $id = $_SESSION['employee'];

                    $sql = "SELECT * From employee where em_id='$id'";
                    $run = $conn->prepare($sql);
                    $run->execute();

                    if($run->rowCount() > 0) {
                        while ($row = $run->fetch(PDO::FETCH_ASSOC)) {
                            $name = $row["em_name"];
                        }

                    }
                    echo '<li>
                             <a href="">' . $name . '</a>
                         </li>
                         
                         <li>
                              <a href="logout.php">LogOut</a>
                         </li>';
                }
                else if(isset($_SESSION['hr'])) {
                    echo '<li>
                         <a href="hrpanel.php">Dashboard</a>
                    </li>';

                $id = $_SESSION['hr'];

                $sql = "SELECT * From hradmin where hr_id='$id'";
                $run = $conn->prepare($sql);
                $run->execute();

                if($run->rowCount() > 0) {
                    while ($row = $run->fetch(PDO::FETCH_ASSOC)) {
                        $name = $row["hr_name"];
                    }

                }
                echo '<li>
                             <a href="employee.php">'. $name .'</a>
                         </li>
                         
                         <li>
                              <a href="logout.php">LogOut</a>
                         </li>';
            }
            else if(isset($_SESSION['admin'])) {
                echo '<li>
                         <a href="adminpanel.php">Dashboard</a>
                    </li>';

                    $id = $_SESSION['admin'];

                    $sql = "SELECT * From admin where admin_id='$id'";
                    $run = $conn->prepare($sql);
                    $run->execute();

                    if($run->rowCount() > 0) {
                        while ($row = $run->fetch(PDO::FETCH_ASSOC)) {
                            $name = $row["admin_name"];
                        }

                    }
                    echo '<li>
                             <a href="employee.php">'. $name .'</a>
                         </li>
                         
                         <li>
                              <a href="logout.php">LogOut</a>
                         </li>';
            }
            else{

                    echo'<li>
                           <a href="login.php">LogIn</a>
                        </li>
                      ';
                }
            ?>

            <li>
                <a href="contact.php">Contact</a>
            </li>
            <!-- li end -->
        </ul>

        <!-- Mod-->
        <div class="module module-search pull-left">
            <div class="search-icon">
                <i class="fa fa-search"></i>
                <span class="title">search</span>
            </div>
            <div class="search-box">
                <?php
                     if(isset($_POST["search"])){
                         $topic = trim($_POST['search_word']);
                         header("Location: search_result.php?category=$topic");
                     }
                ?>
                <form class="search-form" method="post">
                    <div class="form-group">
                        <input class="text" placeholder="Type Your Search Words" id="search_word" name="search_word" required="">
                    </div>
                    <button type="submit" class="btn btn-primary m-b" id="search" name="search">
                        Search
                    </button>
                    <!-- /input-group -->
                </form>
            </div>
        </div>
        <!-- .module-search-->

    </div>
    <!-- /.navbar-collapse -->
</div>
<!-- /.container-fluid -->
