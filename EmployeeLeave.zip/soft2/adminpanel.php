<?php
include "db.php";
session_start();
$id = $_SESSION['admin'];
?>



<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
<!-- Document Meta
    ============================================= -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--IE Compatibility Meta-->
<meta name="author" content="zytheme" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="description" content="construction html5 template">
<link href="assets/images/favicon/favicon.ico" rel="icon">

<!-- Fonts
    ============================================= -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i%7CRaleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i%7CUbuntu:300,300i,400,400i,500,500i,700,700i' rel='stylesheet' type='text/css'>

<!-- Stylesheets
    ============================================= -->
<link href="assets/css/external.css" rel="stylesheet">
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/custom.css" rel="stylesheet">

<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
<!--[if lt IE 9]>
      <script src="assets/js/html5shiv.js"></script>
      <script src="assets/js/respond.min.js"></script>
    <![endif]-->

<!-- Document Title
    ============================================= -->
<title>Leave Management</title>

    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }
    </style>
</head>
<body>
<!-- Document Wrapper
	============================================= -->
<div id="wrapper" class="wrapper clearfix">
    <header id="navbar-spy" class="header header-1">

        <!-- .top-bar end -->
        <nav id="primary-menu" class="navbar navbar-fixed-top">
            <?php include 'inc/nav.php'; ?>
        </nav>
    </header>
	
	<!-- Page Title
============================================= -->
	<section id="page-title" class="page-title">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-6">
					<h1>Admin Panel</h1>
				</div>
				<!-- .col-md-6 end -->
				<div class="col-xs-12 col-sm-12 col-md-6">
					<ol class="breadcrumb text-right">
						<li>
							<a href="adminpanel.php"></a>
						</li>
						<li class="active"></li>
					</ol>
				</div>
				<!-- .col-md-6 end -->
			</div>
			<!-- .row end -->
		</div>
		<!-- .container end -->
	</section>
	<!-- #page-title end -->
	
	<!-- Shop Single right sidebar
============================================= -->

    <section id="shopgrid" class="shop shop-single">
        <div class="container shop-content">


            <button  class="btn btn-lg btn-primary" id="employee" onclick="employee()" style="background-color: darkred ">EMPLOYEE</button>
            <button  class="btn btn-lg btn-primary" id="project" onclick="project()">PROJECT</button>
            <button  class="btn btn-lg btn-primary" id="hr" onclick="hr()">HR Admin</button>
            <div id="employee1">

                    <a class="btn btn-lg btn-primary btn-block"  style="margin-top: 80px; background: #00ACEE;" href="register.php">ADD Employee</a>
                    <table border = "1">
                    <?php

                           echo '
                              <tr  border = "2">
                                 <td>ID</td>
                                 <td>Name</td>
                                 <td>Phone</td>
                                 <td>Department</td>
                                 <td>Address</td>
                                 <td>Action</td>
                                 
                              </tr>';

                $sql = "SELECT * From employee";
                $run = $conn->prepare($sql);
                $run->execute();

                if($run->rowCount() > 0) {
                    while ($row = $run->fetch(PDO::FETCH_ASSOC)) {
                        $id = $row["em_id"];
                        $name = $row["em_name"];
                        $dept = $row["em_department"];
                        $cont = $row["em_phone"];
                        $address = $row["em_address"];

                        $sqldept = "SELECT dep_name From department where dep_id='$dept'";
                        $rundept = $conn->prepare($sqldept);
                        $rundept->execute();
                        $rowdept = $rundept->fetch(PDO::FETCH_ASSOC);
                        $dept_name=$rowdept["dep_name"];

                            echo'<tr>
                                 <td>'.$id.'</td>
                                 <td>'.$name.'</td>
                                 <td>'.$cont.'</td>
                                 <td>'.$dept_name.'</td>
                                 <td>'.$address. '</td>
                                 <td>                                      
                                       <a class="btn-primary"  style="margin-top: 80px; background: #ee0c22;" href="employee.php?id='.$id.'">Edit</a>                                      
                                 </td>                                      
                              </tr>';
                    }
                }
                ?>
                </table>
            </div>
            <div id="project1" style="display: none">
                <p>Hello World</p>
            </div>
            <div id="hr1" style="display: none">


                <a class="btn btn-lg btn-primary btn-block"  style="margin-top: 80px; background: #00ACEE;" href="hradd.php"> ADD HR </a>
                <table border = "1">
                    <?php

                    echo '
                              <tr  border = "2">
                                 <td>ID</td>
                                 <td>Name</td>
                                 <td>Phone</td>
                                 <td>Department</td>
                                 <td>Address</td>
                                 <td>Action</td>
                                 
                              </tr>';

                    $sql = "SELECT * FROM hradmin";
                    $run = $conn->prepare($sql);
                    $run->execute();

                    if($run->rowCount() > 0) {
                        while ($row = $run->fetch(PDO::FETCH_ASSOC)) {
                            $id = $row["hr_id"];
                            $name = $row["hr_name"];
                            $dept = $row["hr_department"];
                            $cont = $row["hr_phone"];
                            $address = $row["hr_address"];

                            $sqldept = "SELECT dep_name From department where dep_id='$dept'";
                            $rundept = $conn->prepare($sqldept);
                            $rundept->execute();
                            $rowdept = $rundept->fetch(PDO::FETCH_ASSOC);
                            $dept_name=$rowdept["dep_name"];

                            echo'<tr>
                                 <td>'.$id.'</td>
                                 <td>'.$name.'</td>
                                 <td>'.$cont.'</td>
                                 <td>'.$dept_name.'</td>
                                 <td>'.$address. '</td>
                                 <td>                                      
                                       <a class="btn-primary"  style="margin-top: 80px; background: #ee0c22;" href="hr.php?id='.$id.'">Edit</a>                                      
                                 </td>                                      
                              </tr>';
                        }
                    }
                    ?>
                </table>
            </div>
        </div>
    </section>



	
	<!-- Footer #1
============================================= -->
	<footer id="footer" class="footer footer-1">
		<!-- Footer Info
	============================================= -->
        <?php include 'inc/footer.php'; ?>
		<!-- .footer-copyright end -->
	</footer>
</div>
<!-- #wrapper end -->

<!-- Footer Scripts
============================================= -->

<script type="text/javascript">
    function employee() {
        document.getElementById("employee").style.backgroundColor = "blue";
        document.getElementById("project").style.backgroundColor = "red";
        document.getElementById("hr").style.backgroundColor = "red";
        var x = document.getElementById("project1");
        x.style.display = "none";
        var y = document.getElementById("employee1")
        y.style.display = "block";
        var z = document.getElementById("hr1")
        z.style.display = "none";
    }
    function project() {
        document.getElementById("employee").style.backgroundColor = "red";
        document.getElementById("project").style.backgroundColor = "blue";
        document.getElementById("hr").style.backgroundColor = "red";
        var a = document.getElementById("project1");
        a.style.display = "block";
        var b = document.getElementById("employee1")
        b.style.display = "none";
        var z = document.getElementById("hr1")
        z.style.display = "none";
    }
    function hr() {
        document.getElementById("employee").style.backgroundColor = "red";
        document.getElementById("project").style.backgroundColor = "red";
        document.getElementById("hr").style.backgroundColor = "blue";
        var a = document.getElementById("project1");
        a.style.display = "none";
        var b = document.getElementById("employee1")
        b.style.display = "none";
        var z = document.getElementById("hr1")
        z.style.display = "block";
    }
</script>
<script src="assets/js/jquery-2.2.4.min.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/functions.js"></script>
</body>
</html>