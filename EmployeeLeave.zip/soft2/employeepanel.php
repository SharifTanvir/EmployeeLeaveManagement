<?php
include "db.php";
session_start();
$id = $_SESSION['employee'];
?>
<?php
$errorss=0;
if (isset($_POST['update'])) {
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $dept = trim($_POST['dept']);



    if(!(strlen($phone) == 11)){

        echo '<script>alert("Phone Number must contain 11 digits. Example : 01700000000");</script>';

        $errorss=1;
    }
    else{
        $sql = "SELECT em_id FROM employee WHERE em_phone = '$phone' and em_id != $id" ;
        $check_query = $conn->prepare($sql);
        $check_query->execute();

        if($check_query->rowCount() > 0){

            echo '<script>alert("Phone number aready exists. Please try with different number.");</script>';

            $errorss=1;
        }
    }
    if (isset($_POST['update']) && $errorss==0) {
        $sqlupload= "UPDATE employee SET em_phone='$phone',em_address='$address',em_department='$dept' where employee.em_id=$id ";
        $runupload = $conn->prepare($sqlupload);
        $runupload->execute();

        header("Location: employee.php");


    } else {
        echo '<script>alert("error");</script>';
    }

}
?>


<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
<!-- Document Meta
    ============================================= -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--IE Compatibility Meta-->
<meta name="author" content="zytheme" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="description" content="construction html5 template">
<link href="assets/images/favicon/favicon.ico" rel="icon">

<!-- Fonts
    ============================================= -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i%7CRaleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i%7CUbuntu:300,300i,400,400i,500,500i,700,700i' rel='stylesheet' type='text/css'>

<!-- Stylesheets
    ============================================= -->
<link href="assets/css/external.css" rel="stylesheet">
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/custom.css" rel="stylesheet">

<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
<!--[if lt IE 9]>
      <script src="assets/js/html5shiv.js"></script>
      <script src="assets/js/respond.min.js"></script>
    <![endif]-->

<!-- Document Title
    ============================================= -->
<title>Leave Management</title>

    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }
    </style>
</head>
<body>
<!-- Document Wrapper
	============================================= -->
<div id="wrapper" class="wrapper clearfix">
    <header id="navbar-spy" class="header header-1">

        <!-- .top-bar end -->
        <nav id="primary-menu" class="navbar navbar-fixed-top">
            <?php include 'inc/nav.php'; ?>
        </nav>
    </header>
	
	<!-- Page Title
============================================= -->
	<section id="page-title" class="page-title">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-6">
					<h1>Employee Panel</h1>
				</div>
				<!-- .col-md-6 end -->
				<div class="col-xs-12 col-sm-12 col-md-6">
					<ol class="breadcrumb text-right">
						<li>
							<a href="employeepanel.php"></a>
						</li>
						<li class="active"></li>
					</ol>
				</div>
				<!-- .col-md-6 end -->
			</div>
			<!-- .row end -->
		</div>
		<!-- .container end -->
	</section>
	<!-- #page-title end -->
	
	<!-- Shop Single right sidebar
============================================= -->

    <section id="shopgrid" class="shop shop-single">
        <div class="container shop-content">


            <button  class="btn btn-lg btn-primary" id="employee" onclick="Info()" style="background-color: darkred ">INFO</button>
            <button  class="btn btn-lg btn-primary" id="project" onclick="leaveinfo()">Leave Info</button>
            <button  class="btn btn-lg btn-primary" id="hr" onclick="hr()">Other</button>
            <div id="employee1">

                <section id="shopgrid" class="shop shop-single">
                    <div class="container shop-content">
                        <?php
                        if (! empty($errors)) {
                            ?>
                            <div class="alert alert-warning">
                                <?php
                                foreach ($errors as $error) {
                                    ?>
                                    <ul>
                                        <li><?php echo $error; ?></li>
                                    </ul>
                                    <?php
                                }
                                ?>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="row">

                        </div>
                        <!-- .row end -->
                        <?php
                        $iid=$id;

                        $sql = "SELECT * From employee where em_id='$iid'";
                        $run = $conn->prepare($sql);
                        $run->execute();

                        if($run->rowCount() > 0) {
                            while ($row = $run->fetch(PDO::FETCH_ASSOC)) {
                                $name = $row["em_name"];
                                $dept = $row["em_department"];
                                $cont = $row["em_phone"];
                                $address = $row["em_address"];

                                $sql = "SELECT dep_name From department where dep_id='$dept'";
                                $run = $conn->prepare($sql);
                                $run->execute();
                                $row = $run->fetch(PDO::FETCH_ASSOC);
                                $dept_name=$row["dep_name"];




                                echo '
                  <div class="row">
				      
                <div class="col-xs-12 col-sm-12 col-md-7">
                  <div class="product-title text-center-xs">
                     <h3>' . $name . '</h3>
                     <h3>ID: ' . $iid . '</h3>
                   </div>';
                            }
                        }
                        ?>
                        <form action="" method="post"  style="margin-top: 80px;" enctype="multipart/form-data">

                            <label for="inputPhonenumber">Phone Number</label>
                            <input type="text" name="phone" class="form-control" value=<?php echo "'$cont'";?>  autofocus required="">
                            <label for="inputDescription">Department</label>
                            <input type="text" name="dept" class="form-control"  value=<?php echo "'$dept_name'";?>  required="" readonly>
                            <label for="inputDescription">Address</label>
                            <input type="text" name="address" class="form-control"  value=<?php echo "'$address'";?> required="">

                            <button class="btn btn-lg btn-primary btn-block"  style="margin-top: 80px;" type="submit" name="update">Update</button>
                        </form>
                        <!-- .product-share end -->
                    </div>
            </div>
            <!-- .row end -->
            <!-- .row end -->
            <div>   </div>

            <!-- .row end -->
            <!-- .product-related end -->
        </div>
        <!-- .container end -->
            </section>
            </div>
            <div id="project1" style="display: none">

                <?php
                $sql = "SELECT * FROM supervisor WHERE supervisor.supervisor_id = '$iid'" ;
                $check_query = $conn->prepare($sql);
                $check_query->execute();
                if($check_query->rowCount() > 0){

                    while ($row = $check_query->fetch(PDO::FETCH_ASSOC)) {
                        echo '<a class="btn btn-lg btn-primary "  style="margin-top: 80px; background: #00ACEE;" href="leaveapplication2.php">Apply For Leave</a>';
                    }
                }
                else{
                    echo '<a class="btn btn-lg btn-primary "  style="margin-top: 80px; background: #00ACEE;" href="leaveapplication.php">Apply For Leave</a>';
                }

                ?>

            </div>

            <div id="hr1" style="display: none">




                    <?php

                    echo '<table border = "1">
                      <tr  border = "2">
                        <td>Serial</td>
                        <td>Name</td>
                        <td>From</td>
                        <td>To</td>
                        <td>Description</td>
                        <td>Action</td>

                      </tr>';

                    $sql = "SELECT * From infoofleave where leave_monitorer='$id'";
                    $run = $conn->prepare($sql);
                    $run->execute();

                    if($run->rowCount() > 0) {
                        while ($row = $run->fetch(PDO::FETCH_ASSOC)) {
                            $serial = $row["l_id"];
                            $emid = $row["employee_id"];
                            $from = $row["l_from"];
                            $to = $row["l_to"];
                            $des = $row["l_des"];
                            $status= $row["l_status"];
                            $st="accepted";
                            $st2="rejected";

                          if($status == "pending"){

                            $sqldept = "SELECT em_name From employee where em_id='$emid'";
                            $rundept = $conn->prepare($sqldept);
                            $rundept->execute();
                            $rowdept = $rundept->fetch(PDO::FETCH_ASSOC);
                            $name2 = $rowdept["em_name"];


                            echo'<tr>
                                 <td>'.$serial.'</td>
                                 <td>'.$name2.'</td>
                                 <td>'.$from.'</td>
                                 <td>'.$to.'</td>
                                 <td>'.$des. '</td>
                                 <td> 
                                                                           
                                      <a  class="btn btn-primary" href="accept-reject.php?id='.$serial.'&status='.$st.'"  style=" background: #15ee87;"  id="accept" name="accept">Accept</a><br><br> 
                                      <a  class="btn btn-primary"  href="accept-reject.php?id='.$serial.'&status='.$st2.'"  style=" background: #ee0c22;"  id="reject" name="reject">Reject</a>                                    
                                 </td>                                      
                              </tr>';
                          }
                        }
                    }


                    ?>
                </table>


                </table>

            </div>
        </div>
    </section>



	
	<!-- Footer #1
============================================= -->
	<footer id="footer" class="footer footer-1">
		<!-- Footer Info
	============================================= -->
        <?php include 'inc/footer.php'; ?>
		<!-- .footer-copyright end -->
	</footer>
</div>
<!-- #wrapper end -->

<!-- Footer Scripts
============================================= -->

<script type="text/javascript">
    function Info() {
        document.getElementById("employee").style.backgroundColor = "blue";
        document.getElementById("project").style.backgroundColor = "red";
        document.getElementById("hr").style.backgroundColor = "red";
        var x = document.getElementById("project1");
        x.style.display = "none";
        var y = document.getElementById("employee1")
        y.style.display = "block";
        var z = document.getElementById("hr1")
        z.style.display = "none";
    }
    function leaveinfo() {
        document.getElementById("employee").style.backgroundColor = "red";
        document.getElementById("project").style.backgroundColor = "blue";
        document.getElementById("hr").style.backgroundColor = "red";
        var a = document.getElementById("project1");
        a.style.display = "block";
        var b = document.getElementById("employee1")
        b.style.display = "none";
        var z = document.getElementById("hr1")
        z.style.display = "none";
    }
    function hr() {
        document.getElementById("employee").style.backgroundColor = "red";
        document.getElementById("project").style.backgroundColor = "red";
        document.getElementById("hr").style.backgroundColor = "blue";
        var a = document.getElementById("project1");
        a.style.display = "none";
        var b = document.getElementById("employee1")
        b.style.display = "none";
        var z = document.getElementById("hr1")
        z.style.display = "block";
    }
</script>
<script src="assets/js/jquery-2.2.4.min.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/functions.js"></script>
</body>
</html>